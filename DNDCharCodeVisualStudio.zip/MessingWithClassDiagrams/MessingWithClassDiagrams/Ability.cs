﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessingWithClassDiagrams
{
    public class Ability
    {
        private int AbilityScore;
        private List<Skill> Skills;

        public int Mod()
        {
            int toreturn = 0;
            toreturn = AbilityScore - 10;
            if (toreturn > 0)
            {
                toreturn /= 2;
            }else if (toreturn < 0)
            {
                toreturn *= -1;
                toreturn += 1;
                toreturn /= 2;
                toreturn *= -1;
            }
            return toreturn;
        }
    }
}