﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessingWithClassDiagrams
{
    public class Character
    {
        private List<CharacterClass> Classes;
        private Race Race;
        private List<Ability> Abilities;
        private List<Item> Inventory;
    }
}