﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessingWithClassDiagrams
{
    public abstract class CharacterClass
    {
        private int Level;
        private int HitDie;
        private List<Feat> Features;
        private List<Spell> Spells;
    }
}