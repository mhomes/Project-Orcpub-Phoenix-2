﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MessingWithClassDiagrams
{
    public class Spell
    {
        private List<CharacterClass> Classes;
        private bool Verbal;
        private bool Somatic;
        private bool Material;
    }
}